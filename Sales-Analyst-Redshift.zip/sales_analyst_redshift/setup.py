"""
Setup script for the GenAI Sales Analyst application.
"""
from src.utils.setup_utils import run_setup

if __name__ == "__main__":
    run_setup()